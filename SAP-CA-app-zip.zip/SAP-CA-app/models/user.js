//user.js class to define a user, having both its username and password.
module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define("User", {
        username: {type: DataTypes.STRING, unique: true, allowNull: false, unique: true},
        password: {type: DataTypes.STRING, allowNull: false}
    });
    return User;
};