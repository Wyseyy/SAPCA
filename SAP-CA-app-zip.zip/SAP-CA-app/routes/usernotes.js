const express = require("express");
const db = require("../models");
const sequelize = db.sequelize;
const Notes = db.notes;
const jwt = require("jsonwebtoken");
const router = express.Router();
const SECRET = "insecurepassword";

//middleware.
const auth = (req, res, next) => {
    const token = req.header("Authorization");
    if (!token) return res.status(401).json({ message: "Cannot access"});
    try{
        const verification = jwt.verify(token.replace("Bearer ", ""), SECRET);
        req.user = verification;
        next();
    } catch {
        res.status(400).json({ message: "Token invalid" });
    }
};

router.post("/", auth, async (req, res) => {
    console.log("Request body:", req.body);
    console.log("Authorization header:", req.headers.authorization);
    try{
        const { notetitle, notebody } = req.body;
        if(!notetitle || !notebody){
            console.log("Missing notetitle or notebody");
            return res.status(400).json({message: "Title and body are required"});
        }
        const query = `INSERT INTO Notes (notetitle, notebody, createdAt, updatedAt) VALUES ('${notetitle}', '${notebody}', NOW(), NOW())`;
        await db.sequelize.query(query);
        res.status(201).send(`<p>Note created: ${notetitle}</p>`);
    } catch (error) {
        console.log("Error:", error);
        res.status(500).json({ error: error.message });
    }
});

router.get("/", auth, async (req, res) => {
    try{
        const [Notes] = await sequelize.query("SELECT * FROM Notes");
        let response = "<h1>Users Notes</h1>";
        Notes.forEach(note => {
            response += `<div><h3>${note.notetitle}</h3><p>${note.notebody}</p></div>`
        });
        res.send(response);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.put("/", auth, async (req, res) => {
    try{
        const { originalTitle, notetitle, notebody } = req.body;
        const query = `UPDATE Notes SET notetitle = '${notetitle}', notebody = '${notebody}' WHERE notetitle = ${originalTitle}`;
        await db.sequelize.query(query, { type: db.sequelize.QueryTypes.UPDATE });
        res.status(200).json({ message: "Note has been updated "});
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error updating note' });
    }
});

router.delete("/", auth, async (req, res) => {
    try{
        const { title } = req.body;
        const query = `DELETE FROM Notes WHERE notetitle = '${title}'`;
        await db.sequelize.query(query, { type: db.sequelize.QueryTypes.DELETE });
        res.status(200).json({ message: "Note has been deleted "});
    } catch(error) {
        res.status(500).json({ error: error.message });
    }
});

router.get("/xss", (req, res) =>{
    const name = req.query.name || "Guest";
    res.send(`<h1>Welcome ${name}</h1>`);
});

module.exports = router;