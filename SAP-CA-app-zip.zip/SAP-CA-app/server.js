require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const db = require("./models");

const app = express();
const PORT = process.env.PORT || 3000;

//This is middleware, functions that allows operations to perform on incoming requests.
app.use(cors());
app.use(helmet());
app.use(morgan("dev"));
app.use(express.json());

//These are routes.
app.use("/authentication", require("./routes/authentication"));
app.use("/usernotes", require("./routes/usernotes"));
app.use(express.static("public"));

//Method to sync the database to the project.
db.sequelize.sync().then(() =>{
    console.log("Database has connected.");
    app.listen(PORT, () => console.log(`Server on port ${PORT}`));
}).catch(err => console.log("Error: "+ err));
