const express = require("express");
const db = require("../models");
const sequelize = db.sequelize;
const Notes = db.notes;
const jwt = require("jsonwebtoken");
const router = express.Router();
const dotenv = require("dotenv");
dotenv.config();
const SECRET = process.env.JWT_SECRET || "fallback-secret";

//middleware.
const auth = (req, res, next) => {
    const token = req.header("Authorization");
    if (!token) return res.status(401).json({ message: "Cannot access"});
    try{
        const verification = jwt.verify(token.replace("Bearer ", ""), SECRET);
        req.user = verification;
        next();
    } catch {
        res.status(400).json({ message: "Token invalid" });
    }
};

router.post("/", auth, async (req, res) => {
    try{
        const { notetitle, notebody } = req.body;
        if(!notetitle || !notebody){
            return res.status(400).json({message: "Title and body are required"});
        }
        await sequelize.query(`INSERT INTO Notes (notetitle, notebody, createdAt, updatedAt) VALUES (?, ?, NOW(), NOW())`,
            {
                replacements: [notetitle, notebody],
                type: sequelize.QueryTypes.INSERT
            }
        );
        res.status(201).json({ message: "Note created!"});
    } catch (error) {
        console.log("Error:", error);
        res.status(500).json({ error: error.message });
    }
});

router.get("/", auth, async (req, res) => {
    try{
        const Notes = await sequelize.query("SELECT * FROM Notes", {
            type: sequelize.QueryTypes.SELECT
        });
        let response = "<h1>Users Notes</h1>";
        Notes.forEach(note => {
            const secureTitle = escapeHTML(note.notetitle);
            const secureBody = escapeHTML(note.notebody);
            response += `<div><h3>${secureTitle}</h3><p>${secureBody}</p></div>`
        });
        res.send(response);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.put("/", auth, async (req, res) => {
    try{
        const { originalTitle, notetitle, notebody } = req.body;
        if (!originalTitle || !notetitle || !notebody) {
            return res.status(400).json({ message: "All fields required" });
        }
        await sequelize.query(
            `UPDATE Notes SET notetitle = ?, notebody = ? WHERE notetitle = ?`,
            {
                replacements: [notetitle, notebody, originalTitle],
                type: sequelize.QueryTypes.UPDATE
            }
        );
        res.status(200).json({ message: "Note has been updated "});
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error updating note' });
    }
});

router.delete("/", auth, async (req, res) => {
    try{
        const { title } = req.body;
        console.log("Received title in DELETE:", title);
        if (!title) {
            return res.status(400).json({ message: "Title required" });
        }
        console.log("Attempting to delete note with title:", title);

        await sequelize.query(
            `DELETE FROM Notes WHERE notetitle = ?`,
            {
                replacements: [title]
            }
        );
        res.status(200).json({ message: "Note has been deleted "});
    } catch(error) {
        console.error("Error in DELETE route:", error);
        res.status(500).json({ error: error.message });
    }
});

router.get("/xss", (req, res) =>{
    const name = req.query.name || "Guest";
    res.send(`<h1>Welcome ${escapeHTML(name)}</h1>`);
});

function escapeHTML(str){
    return str.replace(/[&<>"']/g, function (m) {
            return ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;',
        })[m];
    });
}

module.exports = router;