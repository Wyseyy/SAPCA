//class to authenticate the user.
const dotenv = require('dotenv');
dotenv.config();
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../models");
const { User } = db;
const sequelize = db.sequelize;

const routers = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "fallback-secret";

//Method to register a user
routers.post("/register", async (req, res) =>{
    try{
        const { username, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await User.create({ username, password: hashedPassword });
        res.status(201).json({message: "User has been registered", username, password});
    } catch (error){
        console.error("Error Registering: ", error);
        res.status(500).json({ error: error.message });
    }
});

//method to log a user in
routers.post("/login", async (req, res) => {
    try{
        const { username, password} = req.body;
        const user = await User.findOne({ where : { username } });
        if (!user) {
            return res.status(401).json({ message: "Invalid username or password"});
        }
        const passwordMatches = await bcrypt.compare(password, user.password);
        if (!passwordMatches){
            return res.status(401).json({message: "Invalid username or password"});
        }
        const token = jwt.sign({ username: user.username }, JWT_SECRET, {expiresIn: "1h" });
        res.json({ token });
    } catch (error){
        console.error("Login error:", error);
        res.status(500).json({ message: "Error with server during login" });
    }
});

function auth(req, res, next) {
    const token = req.header("Authorization")?.replace("Bearer ", "");
    
    if (!token) {
        return res.status(401).json({ message: "Authentication required" });
    }

    try {
        const decode = jwt.verify(token, JWT_SECRET);
        req.user = decode;
        next();  
    } catch (error) {
        return res.status(400).json({ message: "Token invalid" });
    }
}
module.exports = routers;