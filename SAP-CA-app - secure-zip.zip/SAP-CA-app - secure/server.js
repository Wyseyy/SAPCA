require("dotenv").config();
const express = require("express");
const cors = require("cors");
const crypto = require('crypto');
const helmet = require("helmet");
const morgan = require("morgan");
const db = require("./models");

const app = express();
const PORT = process.env.PORT || 3000;

// This is middleware, functions that allow operations to perform on incoming requests.
app.use(cors());
app.use(helmet());
app.use(morgan("dev"));
app.use(express.json());

app.use((req, res, next) => {
    const csp = "default-src 'self'; script-src 'self', 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self' http://localhost:3000; object-src 'none'; frame-ancestors 'none'; base-uri 'none';";
    res.setHeader("Content-Security-Policy", csp);
    next();
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

// These are routes.
const userRoutes = require("./routes/usernotes");
app.use('/usernotes', userRoutes);
const authenticationRoutes = require("./routes/authentication");
app.use('/authentication', authenticationRoutes);
app.use(express.static("public"));

// Method to sync the database to the project.
db.sequelize.sync().then(() => {
    console.log("Database has connected.");
    app.listen(PORT, () => console.log(`Server on port ${PORT}`));
}).catch(err => console.log("Error: " + err));
