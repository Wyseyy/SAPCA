const { test, expect } = require('@playwright/test');

const BASE_URL = 'http://localhost:3000';

async function login(page) {
    await page.goto(BASE_URL);
    await page.fill('#loginUser', 'playwrightuser');
    await page.fill('#loginPassword', 'testpassword');
    await page.click('#LoginUser >> button');
    await page.once('dialog', dialog => dialog.accept());
    await page.waitForSelector('#createNote', { timeout: 5000 });
}

test.describe('SAP test', () => {
    test.beforeEach(async ({ page }) => {
        await page.goto(BASE_URL);
    });

    test('Register with valid information', async ({ page }) => {
        await page.fill('#registerUser', 'playwrightuser');
        await page.fill('#registerPassword', 'testpassword');
        await page.click('#RegisterUser >> button');
        await page.once('dialog', dialog => dialog.accept());
    });

    test('Login with correct information', async ({ page }) => {
        await login(page);
        await expect(page.locator('#createNote')).toBeVisible();
    });

});
