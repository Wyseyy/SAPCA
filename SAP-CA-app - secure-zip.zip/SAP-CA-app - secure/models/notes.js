module.exports = (sequelize, DataTypes) => {
    const Notes = sequelize.define('Notes', {
        notetitle: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        notebody: {
            type: DataTypes.TEXT,
            allowNull: false,
        },
        username: {
            type: DataTypes.STRING,
            allowNull: false
        }
    });
    
    return Notes;
};
