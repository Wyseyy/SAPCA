const { Sequelize } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(
    process.env.DB_NAME,
    process.env.DB_USER,
    process.env.DB_PASS,
    process.env.DB_PORT,
    process.env.DB_HOST,
    {
        host: process.env.DB_HOST,
        dialect: process.env.DB_DIALECT || 'mysql',
        port: process.env.DB_PORT
    }
);

sequelize.authenticate()
    .then(() => {
        console.log('Connection established');
    })
    .catch(err => {
        console.log('Unable to connect', err);
    });

sequelize.sync({force: false})
    .then(( ) => {
        console.log('Database sync successful');
    })
    .catch(err => {
        console.error('Unable to sync', err);
    });
    

module.exports = sequelize;