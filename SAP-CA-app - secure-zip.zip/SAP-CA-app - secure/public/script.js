const API = "http://localhost:3000";
let token = sessionStorage.getItem("token") || "";

function escapeHTML(str) {
    return str.replace(/[&<>"']/g, (char) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    }[char]));
}

document.getElementById("RegisterUser").addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = registerUser.value;
    const password = registerPassword.value;
    try {
        const res = await fetch(`${API}/authentication/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        });

        const data = res.ok ? await res.json() : await res.text();
        if (res.ok){
            alert("User Registered!");
        } else {
            alert(`Registration failed: ${data.error}`);
        }
    } catch (err) {
        console.error("Registration Error:", err);
        alert("Registration failed.");
    }
});

document.getElementById("LoginUser").addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = document.getElementById("loginUser").value
    const password = document.getElementById("loginPassword").value;
    const res = await fetch(`${API}/authentication/login`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({username, password})
    });
    const userdata = await res.json();
    if(res.ok && userdata.token) {
        token = userdata.token;
        localStorage.setItem("token", token);
        alert("Logged in!");
        viewNotes();
    } else {
        alert("Login failed: " + (userdata.message || "Error unknown"));
    }
});

document.getElementById("createNote").addEventListener("submit", async (e) => {
    e.preventDefault();
    const notetitle = document.getElementById("title").value;
    const notebody = document.getElementById("body").value;
    const token = localStorage.getItem("token");
    if(!token){
        alert("You must be logged in to create notes.");
        return;
    }
    const res = await fetch(`${API}/usernotes`, {
        method: "POST",
        headers: {"Content-Type": "application/json", "Authorization": "Bearer " + token },
        body: JSON.stringify({notetitle, notebody}),
    });
    if(res.ok){
        alert("Note has been added.");
        viewNotes();
    } else {
        const response = await res.json();
        console.error("Error", response);
        alert("Failed to add note, Please try again");
    }
});

async function viewNotes() {
    const token = localStorage.getItem("token");
    if (!token) {
        alert("You must be logged in to view your notes.");
        return;
    }

    const res = await fetch(`${API}/usernotes`, {
        headers: { "Authorization": "Bearer " + token }
    });

    const html = await res.text();
    const container = document.getElementById("notesFunctions");
    container.innerHTML = "";

    const parse = new DOMParser();
    const parsedHTML = parse.parseFromString(html, "text/html");
    const notes = parsedHTML.querySelectorAll("div");

    notes.forEach((note, index) => {
        const id = note.getAttribute('data-id');
        const title = note.querySelector("h3").textContent;
        const content = note.querySelector("p").textContent;

        const wrapper = document.createElement("div");
        wrapper.innerHTML = `
            <h3>Title: <input value="${escapeHTML(title)}" id="editTitle${index}" /></h3>
            <p>Body: <textarea id="editContent${index}">${escapeHTML(content)}</textarea></p>
            <button class="edit-btn" data-index="${index}" data-original-title="${title}">Edit Note</button>
            <button class="delete-btn" data-title="${title}">Delete Note</button>
        `;

        container.appendChild(wrapper);
    });

    const deleteButtons = container.querySelectorAll(".delete-btn");
    deleteButtons.forEach(button => {
        button.addEventListener("click", (e) => {
            const title = e.target.getAttribute("data-title");
            if (confirm("Are you sure you want to delete this note?")) {
                deleteNotes(title);
            }
        });
    });
}


async function editNotes(originalTitle, index, updatedTitle, updatedContent){
    const token = localStorage.getItem("token");
    const res = await fetch(`${API}/usernotes`, {
        method: "PUT",
        headers: {"Content-Type": "application/json", "Authorization": "Bearer " + token },
        body: JSON.stringify({originalTitle, notetitle: updatedTitle, notebody: updatedContent}),
    });
    if (res.ok){
        viewNotes();
    } else {
        const error = await res.json();
        alert("Edit has failed " + (error.message || "Error"));
    }
}

async function deleteNotes(title) {
    const token = localStorage.getItem("token");
    if (!token) {
        alert("You must be logged in to delete notes.");
        return;
    }

    try {
        const res = await fetch(`${API}/usernotes`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify({ title: title })
        });

        if (res.ok) {
            alert("Note deleted successfully!");
            viewNotes();
        } else {
            const errText = await res.text();
            alert("Failed to delete note: " + errText);
        }
    } catch (err) {
        console.error("Error deleting note:", err);
        alert("An error occurred while deleting the note.");
    }
}

